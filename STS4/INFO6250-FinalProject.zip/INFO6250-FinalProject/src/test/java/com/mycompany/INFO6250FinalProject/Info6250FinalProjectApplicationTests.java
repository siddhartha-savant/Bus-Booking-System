package com.mycompany.INFO6250FinalProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Info6250FinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
