package com.mycompany.INFO6250FinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Info6250FinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Info6250FinalProjectApplication.class, args);
	}

}
